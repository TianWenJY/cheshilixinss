import * as smart from './module/smart'

export default {
    smart
}
