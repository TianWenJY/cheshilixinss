<template>
    <div>
        <el-row>
            <router-link to="/generalPart">
                <el-button>主板块</el-button>
            </router-link>
            <router-link to="/PiccPart">
                <el-button type="primary">picc</el-button>
            </router-link>
            <el-button type="success">无感支付</el-button>
            <el-button type="info">停车场</el-button>
        </el-row>
    </div>
</template>
