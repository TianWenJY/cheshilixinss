'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_BASEURL: '"http://api.cheshili.com.cn/"'
}
